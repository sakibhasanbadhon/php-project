
<?php 

include 'lib/database.php';
$db = new database();

if (isset($_POST["submit"])) {
		
		$fullname = $db->validate($_POST['fullname']);
		$details = $db->validate($_POST['details']);
		
	if (empty($fullname || $details)){
	
		echo "<script> alert(' Its empty Boss'); </script>";
	

	}else{


		 $x="INSERT INTO post(fullname, details) values ('$fullname','$details')";

		    $xx = $db->insert($x);

		    if ($xx) {
		        echo "<script> alert('Data Save Successfull'); </script>";
		  
		    }else{
		        
		        echo "<script> alert('insert faild'); </script>";
		    }
		}

}

 ?>


<!DOCTYPE html>
<!--
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
-->
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />
	<link type="text/css" href="sample/css/sample.css" rel="stylesheet" media="screen" />
	<title>CKEditor 5 – classic editor build sample</title>
</head>
<body>

<strong>sakib Hasna</strong>

	<div class="centered">
		
		<form method="post">
				<input style="padding:10px; width:100%;" type="text" placeholder="Type Somethinks" name="fullname">
				<textarea style="min-height:200px ;" id="editor" placeholder="Please Write Somethinks....." name="details"> </textarea>
			<input style="padding: 10px; width: 100%;margin-top: 20px;background: #00a900;" type="submit" name="submit" value="Update"> <br><br>
			<a style="margin-left: 46%;" href="fetch.php"> View info </a>
		</form>

	</div>

</footer>

<script src="ckeditor.js"></script>

<script>
	ClassicEditor
		.create( document.querySelector( '#editor' ), {
			// toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
		} )
		.then( editor => {
			window.editor = editor;
		} )
		.catch( err => {
			console.error( err.stack );
		} );
</script>

</body>
</html>
