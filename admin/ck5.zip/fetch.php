<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" href="">
</head>
<body>
    

<?php
// Connectionn to database
    $dbhost = 'localhost';
    $dbuser = 'root';
    $dbpassword = '';
    $dbname = 'ck';

    $conn = mysqli_connect($dbhost, $dbuser, $dbpassword, $dbname);
?>

<?php
    
    // Fetching  data
    $sql2 = "SELECT * FROM post;";
    $res = mysqli_query($conn, $sql2);
    $count_rows = mysqli_num_rows($res);

    if($count_rows>0){
        while ($row = mysqli_fetch_assoc($res)){

            $n = htmlspecialchars_decode($row["fullname"]);
            $d = htmlspecialchars_decode($row["details"]);
            

?>

<div style="background:#4ccbb9;padding: 10px;color:black;border:3px solid white;width:70%;margin:0 Auto;">
        <p>  <?php echo $n;  ?> 
        <p>  <?php echo $d;  ?> 
</div>

<?php 

        }
    }

 ?>





</body>
</html>