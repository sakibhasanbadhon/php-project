


<footer class="container-fluid bg-dark text-white" style="">


	<div class="col" style="width: 400px;text-align: center;margin:3% auto;">
		
		<P>Copyright © 2020 Islamteams. All rights reserved <br>
Developed by  <b style="color:#e03737;"> SAKIB </b></P>

	</div>



</footer>











<a id="backtotop"><i class="fa fa-chevron-up"></i></a>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="js/script.js"></script>







</body>
</html>
