
<?php 

include 'inc/header.php';

 ?>



<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<div class="container">

<div class="about_div1">
	<h2>ISLAMTEAMS</h2><br><br>
	<p> <b style="font-size: 30px;">Islam is the solution to humanity.</b> <br> <br> Welcome to Islam's Word of God. On this website, we have highlighted the main points of Islam. It's not just for Muslims, it's for the whole human race. </p>

</div>

	<br><br>
	
<div class="about_div2">

	<b style="font-size: 25px;" >The kind of services you will get here:</b>

<div class="about_div2_li">
	<li>Discuss all aspects of Islam. </li>
	<li>The life story of the prophets . </li>
	<li> What does Islam say about prayers, fasting, Hajj, and Zakat </li>
	<li> Hadith and Sunnah </li>
	<li> Halal food and work are forbidden in Islam.  </li>
	<li> Highlight Islamic News Love. </li>
	<li>  Hadith about love, affection, marriage. </li>
	<li>  Names and biographies of different men in the world. </li>
	<li>  Update Update We started this </li>

</div>
</div>

<br>

<div class="container">
	<div class="col-sm-3 mx-auto"></div>

		<div class="col-sm-5 mx-auto">
			<div class="card p-3">
				<img class="card-img" src="img/sakib.jpg">
				<h2>My self</h2>
				<h3 class="card-title">My name is <a href="https://www.facebook.com/sakibhasan.badhon.9">sakib Hasan Badhon</a>.I have conveyed the message of Allah to teachers, students, and all Muslims here.Because I want mankind to always live in a peaceful way and in accordance with the rules and regulations.</h3>
			</div>
		</div>

	<div class="col-sm-3 mx-auto"></div>

</div>



<!-- <div class="parsonal_info">

	<div class="my_img">
		<img src="img/sakib.jpg">
	</div>

			<p>My name is <a href="https://www.facebook.com/sakibhasan.badhon.9">sakib Hasan Badhon</a>.I have conveyed the message of Allah to teachers, students, and all Muslims here.Because I want mankind to always live in a peaceful way and in accordance with the rules and regulations.</p>

</div> -->



<div class="about_div3">
	<p>website on 5/2/2021 by purchasing a domain and hosting. We believe that our website will benefit all people in the world. Here we are presenting the real issue of Islam. We are on a mission to spread the word of God to the world through this website in a peaceful, humane, and dignified manner.</p>
	
</div>

<div class="about_div3 so">
<h2>Social Contact:</h2> <br>


<li><a href="">Facebook</a> <br></li>
<li><a href="">Twitter</a>	<br></li>
<li><a href="">Instagram</a><br></li>
<li><a href="">Whatsup</a></li>
	
</div>





<img style="width: 100%; height: 400px;" src="img/service8.jpg">






</div>
















</body>
</html>



<?php 

include 'inc/footer.php';

 ?>
