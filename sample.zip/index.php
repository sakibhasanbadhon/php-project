
<?php 

include 'inc/header.php';

include 'inc/top_slider.php';



 ?>

<style type="text/css">


.bani{
  background-image: linear-gradient(174deg, #85FFBD 0%, #FFFB7D 100%);
}

.small-service{
  display: none;
}



</style>
  
<div class="container small-service">
    <h3>services</h3>
  <div class="row" style="">
    <span href=""class="col btn border border-success text-dark">Salat</span>

    <span href=""class="col btn border border-success text-dark">Zakat</span>

    <span href=""class="col btn border border-success text-dark">Hajj</span>

    <span href=""class="col btn border border-success text-dark">World wight time</span>

  </div>
</div>


<div class="container mb-5 mt-3 service">

  <h1>service</h1>

  <div class="row"  style="height: 150px;">

    <div id="col1" class="col-sm border m-2">
      <img class="card-img" src="img/service2.jpg" style="height: 120px;">
      <h4 class="text-center font-weight-bold">Salat</h4>
    </div>    

    <div id="col1" class="col-sm border m-2">
      <img class="card-img" src="img/service3.jpg" style="height: 120px;">
      <h4 class="text-center font-weight-bold">Zakat</h4>
    </div>    

    <div id="col1" class="col-sm border m-2">
      <img class="card-img" src="img/service4.jpg" style="height: 120px;">
      <h4 class="text-center font-weight-bold">Hajj</h4>
    </div>

    <div id="col1" class="col-sm border m-2">
      <img class="card-img" src="img/service5.jpg" style="height: 120px;">
      <h4 class="text-center font-weight-bold"> time</h4>
    </div>

  </div>
</div>





<br>

<?php 




    $bani= "SELECT * from bani";

    $ref = $db->read($bani);

    if ($ref) {
        $data = $ref->fetch_assoc();

    }



 ?>



<div class="container-fluid bg-info text-center bani">
  <div class="container">
    <h3 class=" p-4"><?php echo $data['bani_name']; ?> <br> <small> <i><?php echo $data['sura']; ?></i> </small></h3>
  </div>
</div>



<?php include 'inc/highlight.php'; ?>

<?php include 'inc/web_news.php'; ?>


<div class="container-fluid bg-info text-center bani">
	<div class="container">
		<h3 class=" p-4"><?php echo $data['bani_name']; ?> <br> <small><i><?php echo $data['sura']; ?></i></small></h3>
	</div>
</div>



<div class="container-fluid mt-5" style="background: #ECECEC;">
  <div class="container">

      <h1>Life & Society</h1>
		<div class="row pb-5"> 




<?php 




$total_post = $db->selectTable('post');
$total_post = $total_post->num_rows;
$total_post = ($total_post-6);
$rand = rand(0,$total_post);

$post = "SELECT * FROM post order by ID desc limit $rand,6";
$post_re = $db->read($post);
if ($post_re) {
  while ($post_print = $post_re->fetch_assoc()) {
    


 ?>


    <div id="col" class=" card col-sm-4 pb-2 border" style="min-height: 250px;">
      <img class="card-img pt-3" style="height: 200px;" src="img/<?php echo $post_print['img'] ?>">
      <h4 class="font-weight-bold"><?php echo $post_print['title'] ?></h4>
      <p> <?php echo $db->shortText($post_print['details'],80) ?></p>

      <a href="single.php?proid=<?php echo $post_print['id']; ?>" class="btn btn-outline-success border">view</a>

    </div>  




<?php 



  }
}


 ?>






		</div>


        <div class="highlight_more">
          <a class="highlight_more_a" href=""> <i style="padding-right: 4px;"> more</i><b>HIGHLIGHT <i class="fas fa-arrow-right"></i></b> </a>
        
        </div>

	</div>
</div>










</div>










<?php 

include 'inc/footer.php';

 ?>




