




<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}


input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  outline-color: gray;
}

button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
a {
  text-decoration: none;
  color: white;
}
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;

}

span.psw a{
  color: red;
  text-decoration: none;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}


.log_main{
  width: 50%;
 margin: 2% auto;
 border: 1px solid #ddd;

}

.log_show{
    color: #fb6262;
    text-align: center;
    font-size: 20px;
    background: #63d66342;
      
    width: 350px;
    margin: 1% auto;


}

</style>
</head>
<body>



<div class="log_main">


  <div class="imgcontainer">
    <img src="1.jpg" alt="Avatar" class="avatar">
  </div>



    <script type="text/javascript">
      

      function sakib(){
        setTimeout(function(){

          window.location="index.php";

        },2000);
      }


    </script>









    <?php 



include 'lib/session.php';
session::chksession();

include "lib/database.php";
$db = new database();




$text="";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  

  $u = $_POST['username'];
  $p = $_POST['password'];


  if (empty($u) || empty($p)) {
  
    $text = "empty not allow";

}else{
  $s = "SELECT * FROM admin WHERE user= '$u' and pass='$p'";


    $r =$db->read($s);

    if (!$r) {
      
    $text ="wrong user password";

    }else{
      $text = "<span style='color:green'> success </span>";

      session::set("login",true);
      echo "<script> sakib(); </script>";
    }




}

}


     ?>


<p class="log_show"><?php echo $text; ?></p>

  <div class="container">

<form method="post" action="">
    <b>Username</b>
    <input type="text" placeholder="Enter Username" name="username" required>

    <b>Password</b>
    <input type="password" placeholder="Enter Password" name="password" required>
    <button type="submit" name="submit">Login</button>

    <input type="checkbox" checked="checked" name="remember"> Remember me


  </form>
  </div>






  <div class="container" style="background-color:#f1f1f1">
    <a class="cancelbtn" href="">cansel</a>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>



</div>




</body>
</html>
