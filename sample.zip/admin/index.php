
<?php 

include 'inc/header.php';

include 'inc/sidebar.php';


 ?>


<style type="text/css">
    
    .wrapper .main-container{
  background: url(2.jpg)no-repeat;
  background-size: cover;


}

.show_alldiv{
    width: 100%;
    min-height: 310px;
}


.admin_show{
    width: 300px;
    height: 150px;
    background: white;
    color: black;
    display: inline-flex;
    margin: 13px;
}

.admin_show h2{
    padding: 10px;
    color: #737070;

}

.admin_show h1{
    margin-top: 68px;
    font-size: 40px;
    color: #b3afaf;

}

</style>


    <div class="main-container">


    <div class="show_alldiv">

        <div class="admin_show">
            <h2>Total Post</h2>
            <h1><b> 45 </b></h1>

            
            
        </div>        

        <div class="admin_show">
            <h2>Total product</h2>
            <h1><b> 37 </b></h1>
        </div>       

         <div class="admin_show">
            <h2>Total click</h2>
            <h1><b> 10 </b></h1>
        </div>

        <div class="admin_show">
            <h2> Total Budget</h2>
            <h1><b> 95 </b></h1>
        </div>        

        <div class="admin_show">
            <h2>Total Show</h2>
            <h1><b> 10 </b></h1>
        </div>       

         <div class="admin_show">
            <h2>Total Post</h2>
            <h1><b> 19 </b></h1>
        </div>





    </div>


<div>
   
</div>



    </div>




            <!--main container end-->
</div>
        <!--wrapper end-->



    </body>
</html>
                           