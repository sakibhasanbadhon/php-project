        $(document).ready(function(){
            $(".sidebar-btn").click(function(){
                $(".wrapper").toggleClass("collapse");
            });
        });



      function log(){
        setTimeout(function() {

            window.location="insert.php";

        },1000);

      }



// add categories page



